const env = 'dev'

module.exports = { env }
