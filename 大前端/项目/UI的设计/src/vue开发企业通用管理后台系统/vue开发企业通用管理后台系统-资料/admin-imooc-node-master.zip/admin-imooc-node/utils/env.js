const debug = false
const env = 'prod'

module.exports = {
  debug,
  env
}
